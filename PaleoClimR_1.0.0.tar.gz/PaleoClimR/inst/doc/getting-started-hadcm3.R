## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 5,
  dpi = 96,
  out.width = "100%"
)
library(PaleoClimR)

## ----example-file-------------------------------------------------------------
hadcm3_exp_path <- PaleoClimR.example("HADCM3.permian.example")
hadcm3_file <- "tfkSy_252o.pgclann"

## ----own-data, eval = FALSE---------------------------------------------------
# hadcm3_grid <- HADCM3.grid(
#   file = "your_file_prefix",          # without .nc
#   experiment = "path/to/your/directory",
#   dims = 3
# )

## ----grid---------------------------------------------------------------------
hadcm3_grid <- HADCM3.grid(
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  dims = 3
)

names(hadcm3_grid)

c(
  longitude_cells = length(hadcm3_grid$lon),
  latitude_cells = length(hadcm3_grid$lat),
  depth_levels = length(hadcm3_grid$depth)
)

## ----get-netcdf---------------------------------------------------------------
temperature_nc <- HADCM3.get.nc(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path
)

names(temperature_nc)

dim(temperature_nc$var)

## ----data-2d------------------------------------------------------------------
temperature_surface <- HADCM3.data(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  depth.level = 1
)

head(temperature_surface[!is.na(temperature_surface$var), ])

summary(temperature_surface$var)

## ----data-3d------------------------------------------------------------------
temperature_3d <- HADCM3.data.3D(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path
)

dim(temperature_3d)

head(temperature_3d[!is.na(temperature_3d$var), ])

## ----map----------------------------------------------------------------------
HADCM3.map(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  depth.level = 1,
  unit.factor = 1,
  min.value = -4,
  max.value = 36,
  intervals = 4,
  scale.label = "Temperature (\u00B0C)"
)

## ----transect-----------------------------------------------------------------
HADCM3.transect(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  degrees = 0,
  orientation = "lon",
  continents.outlined = TRUE,
  unit.factor = 1,
  min.value = -4,
  max.value = 36,
  intervals = 4,
  scale.label = "Temperature (\u00B0C)"
)

## ----points-data--------------------------------------------------------------
data("PBDB.permian.example", package = "PaleoClimR")

matched_occurrences <- HADCM3.points.data(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  depth.level = 1,
  coord.dat = PBDB.permian.example
)

head(matched_occurrences[, c(
  "p_lng", "p_lat", "matched_climate", "lon.bin.mid", "lat.bin.mid"
)])

sum(is.na(matched_occurrences$matched_climate))

## ----points-map---------------------------------------------------------------
HADCM3.points.map(
  var = "insitu_T_ym_dpth",
  file = hadcm3_file,
  experiment = hadcm3_exp_path,
  depth.level = 1,
  coord.dat = PBDB.permian.example,
  unit.factor = 1,
  min.value = -4,
  max.value = 36,
  intervals = 4,
  scale.label = "Temperature (\u00B0C)",
  points.col = "phylum",
  points.scale.type = "categorical",
  points.scale.label = "Phylum"
)

