## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 5,
  out.width = "100%"
)
library(PaleoClimR)

## ----example-path-------------------------------------------------------------
cGENIE_exp_path <- PaleoClimR.example("cGENIE.permian.example")

## ----own-data, eval = FALSE---------------------------------------------------
# cGENIE_exp_path <- "/path/to/your/cGENIE/experiment"
# 
# oxygen <- cGENIE.data(
#   var = "ocn_O2",
#   experiment = cGENIE_exp_path,
#   depth.level = 2
# )

## ----grid---------------------------------------------------------------------
cgenie_grid <- cGENIE.grid(
  experiment = cGENIE_exp_path,
  dims = 3
)

c(
  longitude_cells = length(cgenie_grid$lon),
  latitude_cells = length(cgenie_grid$lat),
  depth_levels = length(cgenie_grid$depth)
)

## ----get-netcdf---------------------------------------------------------------
o2_array <- cGENIE.get.nc(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  dims = 3
)

dim(o2_array$var)

## ----years--------------------------------------------------------------------
cGENIE.years(experiment = cGENIE_exp_path)

## ----data-2d------------------------------------------------------------------
oxygen_surface <- cGENIE.data(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2
)

head(oxygen_surface)

## ----data-3d------------------------------------------------------------------
oxygen_3d <- cGENIE.data.3D(
  var = "ocn_O2",
  experiment = cGENIE_exp_path
)

head(oxygen_3d)

## ----bottom-water-data--------------------------------------------------------
bottom_oxygen <- cGENIE.data(
  var = "ocn_ben_O2",
  experiment = cGENIE_exp_path,
  dims = 2
)

head(bottom_oxygen)

## ----map-oxygen---------------------------------------------------------------
cGENIE.map(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2
)

## ----transect-----------------------------------------------------------------
cGENIE.transect(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  degrees = 0,
  orientation = "lon",
  continents.outlined = TRUE,
  unit.factor = 1e6,
  min.value = 0,
  max.value = 320,
  intervals = 40,
  scale.label = "Oxygen (µmol/kg)"
)

## ----adjacent-land------------------------------------------------------------
adjacent_oxygen <- cGENIE.adjacent.land(oxygen_surface)
table(adjacent_oxygen$adj.land)

## ----shelf-data---------------------------------------------------------------
shelf_oxygen <- cGENIE.shelf.data(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2,
  keep.nas = FALSE
)

head(shelf_oxygen[, c("lon.mid", "lat.mid", "var", "adj.land")])

## ----shelf-map----------------------------------------------------------------
cGENIE.shelf.map(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2
)

## ----points-data--------------------------------------------------------------
data("PBDB.permian.example", package = "PaleoClimR")

matched_occurrences <- cGENIE.points.data(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2,
  coord.dat = PBDB.permian.example
)

head(matched_occurrences[, c(
  "p_lng", "p_lat", "matched_climate", "lat.bin.mid", "lon.bin.mid"
)])

## ----points-map---------------------------------------------------------------
cGENIE.points.map(
  var = "ocn_O2",
  experiment = cGENIE_exp_path,
  depth.level = 2,
  coord.dat = PBDB.permian.example,
  points.col = "phylum",
  points.scale.type = "categorical",
  points.scale.label = "Phylum"
)

## ----omz-cells----------------------------------------------------------------
omz_cells <- cGENIE.omz(experiment = cGENIE_exp_path)
head(omz_cells[, c("lon.mid", "lat.mid", "depth", "var", "OMZ.cell")])

## ----omz-summary--------------------------------------------------------------
omz_thickness <- cGENIE.omz.thickness(experiment = cGENIE_exp_path)
head(omz_thickness[, c("lon.mid", "lat.mid", "ocean.thickness", "omz.thickness", "omz.fraction")])

cGENIE.omz.volume(experiment = cGENIE_exp_path)

## ----omz-map------------------------------------------------------------------
cGENIE.omz.map(experiment = cGENIE_exp_path)

## ----bottom-redox-------------------------------------------------------------
cGENIE.bw.redox(experiment = cGENIE_exp_path)

## ----res-import---------------------------------------------------------------
oxygen_series <- cGENIE.res.import(
  var = "ocn_O2",
  experiment = cGENIE_exp_path
)

head(oxygen_series)

## ----res-plot-----------------------------------------------------------------
cGENIE.res.plot(
  var = "ocn_O2",
  experiment = cGENIE_exp_path
)

